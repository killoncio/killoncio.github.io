let ageGroups = [
    {
        from_age: 0,
        to_age: 2,
    },
    {
        from_age: 3,
        to_age: 12,
    },
    {
        from_age: 13,
        to_age: 17,
    },
];

let basePrice = 200;
const currency = 'EUR';
