function getChildrenPolicyViewContent(){
  return `
    <div class="bui-banner__content">
      <h1 class="bui-banner__title">
        <span>Children age groups</span>
      </h1>
      <p class="bui-banner__text">
        <span>You have currently defined 3 children age groups for your entire property:</span>
      </p>
      <ul>
        <li class="children-rate-age__content">${ageGroups[0].from_age}-${ageGroups[0].to_age} years</li>
        <li class="children-rate-age__content">${ageGroups[1].from_age}-${ageGroups[1].to_age} years</li>
        <li class="children-rate-age__content">${ageGroups[2].from_age}-${ageGroups[2].to_age} years</li>
      </ul>
      <button class="bui-button bui-button--secondary" type="button" id="age-preview-banner__change">
        <span class="bui-button__text">Change age groups</span>
      </button>
    </div>
  `;

}
function getChildrenPolicyView() {
    return `
     <div id="age-preview-banner" class="bui-banner age-preview-banner">
        ${getChildrenPolicyViewContent()}
<!--        <button id="age-preview__close"type="button" class="bui-banner__close js-age-preview-banner__close-button"><svg role="presentation" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128"><path d="M69.66,64l33.17-33.17a4,4,0,0,0-5.66-5.66L64,58.34,30.83,25.17a4,4,0,1,0-5.66,5.66L58.34,64,25.17,97.17a4,4,0,1,0,5.66,5.66L64,69.66l33.17,33.17a4,4,0,0,0,5.66-5.66Z"></path></svg></button>-->
      </div>
    `
}

function getMainPage() {
  return ` 
    <div id="img-intro-view" class="children-rate-info">
      <svg fill="currentColor" height="24" role="presentation" viewBox="0 0 24 24" aria-hidden="true" focusable="false" width="24" class="children-rate-info__icon bk-icon -streamline-info_sign"><path d="M14.25 15.75h-.75a.75.75 0 0 1-.75-.75v-3.75a1.5 1.5 0 0 0-1.5-1.5h-.75a.75.75 0 0 0 0 1.5h.75V15a2.25 2.25 0 0 0 2.25 2.25h.75a.75.75 0 0 0 0-1.5zM11.625 6a1.125 1.125 0 1 0 0 2.25 1.125 1.125 0 0 0 0-2.25.75.75 0 0 0 0 1.5.375.375 0 1 1 0-.75.375.375 0 0 1 0 .75.75.75 0 0 0 0-1.5zM22.5 12c0 5.799-4.701 10.5-10.5 10.5S1.5 17.799 1.5 12 6.201 1.5 12 1.5 22.5 6.201 22.5 12zm1.5 0c0-6.627-5.373-12-12-12S0 5.373 0 12s5.373 12 12 12 12-5.373 12-12z"></path></svg>
    </div>

    <h1>Flexible children rates</h1>

    <div id="page" class="bui-grid">
      <div id="left-menu" class="bui-grid__column-full bui-grid__column-4@medium">
        <div id="room-list"></div>
        <div id="policy-banner"></div>
        ${getChildrenPolicyView()}
      </div>
      <div id="right-content" class="bui-grid__column-full bui-grid__column-8@medium">
      </div>
    </div>
  `;
}