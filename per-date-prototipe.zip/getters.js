function hasRatePriceSetup(roomId, rateId) {
  const rates = state[roomId].rates;
  return Object.keys(rates).filter(rateId => rates[rateId].is_rate_set).length;
}



